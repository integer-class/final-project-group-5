# E-Canteen JTI

### Group Member Lists
###### AL AZHAR RIZQI RIFA’I FIRDAUS(2241720263)
###### Ananda Az Haruddin Salima (2241720071)
###### Gastiadirijal Naufaldy Kestiyanto (2241700001)
###### Maulana Dwi Cahyono (2241720241)
###### Renathan Anggoro AW (2241720239)
