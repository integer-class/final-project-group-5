<?php

include "templates/header.php";
include "templates/navbar.php";

?>

<!-- Content -->


<?php

include "templates/footer.php";

?>