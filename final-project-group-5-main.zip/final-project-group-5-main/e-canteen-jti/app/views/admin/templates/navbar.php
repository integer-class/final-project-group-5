<h1>Admin</h1>
<ul>
    <li><a href="/admin/home">Home</a></li>
    <li><a href="/admin/user">User</a></li>
    <li><a href="/admin/product">Product</a></li>
    <li><a href="/admin/report">Report</a></li>
    <li><a href="/logout">logout</a></li>
</ul>