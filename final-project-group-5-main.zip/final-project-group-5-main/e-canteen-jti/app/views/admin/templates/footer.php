<footer>
        <p>&copy; 2023 - E-Canteen JTI</p>
    </footer>

</body>
</html>