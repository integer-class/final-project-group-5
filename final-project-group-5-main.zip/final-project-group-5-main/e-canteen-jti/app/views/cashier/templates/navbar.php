<h1>Cashier</h1>
<ul>
    <li><a href="/cashier/home">Home</a></li>
    <li><a href="/cashier/sales">Sales</a></li>
    <li><a href="/cashier/product">Products</a></li>
    <li><a href="/cashier/report">Report</a></li>
    <li><a href="/logout">logout</a></li>
</ul>