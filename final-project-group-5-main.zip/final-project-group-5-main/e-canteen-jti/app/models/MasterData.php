<?php

namespace models;

class MasterData {

    public function getAll() {
    return;
    }

    public function getDataById($id) {
        return;
    }

    public function create($data) {
        return;
    }

    public function update($data) {
        return;
    }

    public function delete($id) {
        return;
    }
    
}

?>